local options = {
	termguicolors = true -- Allows for more colors than neovim supports automatically
}
