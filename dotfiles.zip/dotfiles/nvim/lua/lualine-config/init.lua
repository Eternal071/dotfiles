require('lualine').setup({options = { theme = 'onedark' }})


