return require('packer').startup(function()
	use 'wbthomason/packer.nvim'
	use 'neovim/nvim-lspconfig'
	use 'nvim-treesitter/nvim-treesitter'
	use 'williamboman/nvim-lsp-installer'
	use 'marko-cerovac/material.nvim'
	use 'nvim-telescope/telescope.nvim' 
	use 'hzchirs/vim-material'
	use {
  		'nvim-lualine/lualine.nvim',
  		requires = { 'kyazdani42/nvim-web-devicons', opt = true }
	}
	use 'nvim-lua/plenary.nvim'
	use 'navarasu/onedark.nvim'
	use {
	  'romgrk/barbar.nvim',
  	requires = {'kyazdani42/nvim-web-devicons'}
	}
	use 'neoclide/coc.nvim'

end)
