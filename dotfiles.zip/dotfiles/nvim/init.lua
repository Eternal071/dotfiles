vim.g.mapleader = " "

vim.o.relativenumber = true
require('pack')
require('lspconfig')
require('options')
require('keymaps')
require('lualine-config')
require('onedark').load()
require('telescope').setup()
vim.cmd ':highlight Normal ctermbg=NONE guibg=NONE'
vim.cmd ':highlight EndOfBuffer guibg=NONE ctermbg=NONE'
